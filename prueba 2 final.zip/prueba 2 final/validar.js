function validar()
{
    //Validacion nombre
    if(document.formulario.txt_nombre.value.length<=2)
    {
        alert("Nombre debe tener más de 3 caracteres")
        document.formulario.datos.txt_nombre.focus()
        return false
    }
    //Validacion apellidos
    if(document.formulario.txt_apellidos.value.length<=3)
    {
        alert("Apellidos deben tener más de 4 caracteres")
        document.formulario.datos.txt_apellidos.focus()
        return false
    }
    //Validacion largo rut
    if(document.formulario.txt_rut.value.length<=8||document.formulario.txt_rut.value.length>10)
    {
        alert("Rut debe tener entre 9 y 10 caracteres")
        document.formulario.datos.txt_rut.focus()
        return false
    }
    //Validacion guion rut
    var rut = document.formulario.txt_rut.value
    var rutInvertido = rut.split('').reverse().join('')
    if(rutInvertido.substring(2,1)!="-")
    {
        alert("Rut debe contener el guión")
        document.formulario.datos.txt_rut.focus()
        return false
    }
    //Validacion mail
    var mail = document.formulario.txt_mail.value
    var mailInvertido = mail.split('').reverse().join('')
    if(mailInvertido.substring(0,10)!="moc.liamg@"&&mailInvertido.substring(0,12)!="moc.liamtoh@")
    {
        alert("mail debe contener el dominio especificado (@gmail.com/@hotmail.com)")
        document.formulario.datos.txt_mail.focus()
        return false
    }
        //Validacion largo teleforno
    if(document.formulario.txt_telefono.value.length<=8||document.formulario.txt_telefono.value.length>9)
    {
        alert("Télefono debe tener entre 8 y 9 números")
        document.formulario.datos.txt_telefono.focus()
        return false
    }
    //Validacion telefono empiece con 9
    if(document.formulario.txt_telefono.value.substring(0,1)!="9")
    {
        alert("El teléfono debe comenzar con 9 sin el mas")
        document.formulario.datos.txt_telefono.focus()
        return false
    }
    //Validación de terminos
    if (document.getElementById("cbox1").checked==false){
        alert("Debe aceptar los Términos y Condiciones");
        document.formulario.rbt_sexo.focus();
        return false;
    }
  

}
function limpiar()
{
    document.getElementById("txt_nombre").value = "";
    document.getElementById("txt_apellidos").value = "";
    document.getElementById("txt_rut").value = "";
    document.getElementById("txt_mail").value = "";
    document.getElementById("txt_telefono").value = "";
    document.getElementById("cbox1").value = false;
}
function resultados() {

    var nombre = document.formulario.txt_nombre.value
    var apellidos = document.formulario.txt_apellidos.value
    var telefono = document.formulario.txt_telefono.value
    var region = document.formulario.sl_region.value


      //Validacion nombre
      if(document.formulario.txt_nombre.value.length<=2)
      {
          return false
      }
      //Validacion apellidos
      if(document.formulario.txt_apellidos.value.length<=3)
      {
          return false
      }
      //Validacion largo rut
      if(document.formulario.txt_rut.value.length<=8||document.formulario.txt_rut.value.length>10)
      {
          return false
      }
      //Validacion guion rut
      var rut = document.formulario.txt_rut.value
      var rutInvertido = rut.split('').reverse().join('')
      if(rutInvertido.substring(2,1)!="-")
      {
          return false
      }
      //Validacion mail
      var mail = document.formulario.txt_mail.value
      var mailInvertido = mail.split('').reverse().join('')
      if(mailInvertido.substring(0,10)!="moc.liamg@"&&mailInvertido.substring(0,12)!="moc.liamtoh@")
      {
          return false
      }
          //Validacion largo teleforno
      if(document.formulario.txt_telefono.value.length<=8||document.formulario.txt_telefono.value.length>9)
      {
          return false
      }
      //Validacion telefono empiece con 9
      if(document.formulario.txt_telefono.value.substring(0,1)!="9")
      {
          return false
      }
      //Validación de terminos
      if (document.getElementById("cbox1").checked==false){
          return false;
      }

   alert("Datos del usuario resigtrado:\n\nNombre: " + nombre + "\nApellidos : " + apellidos + "\nRUT: " + rut + "\nMail: " + mail+ "\nTelefono: " + telefono)
}